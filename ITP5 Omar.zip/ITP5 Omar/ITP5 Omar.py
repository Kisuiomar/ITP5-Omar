import json
import csv


class RentService:
    def __init__(self, name, file_name):
        self.name = name
        self.file_name = file_name
        self.goods = []
        self.load_data()


    def load_data(self):

        try:

            with open(self.file_name, "r") as file:
                reader = csv.reader(file)
                next(reader)

                for row in reader:

                    good = {
                        "id": int(row[0]),
                        "name": row[1],
                        "description": row[2],
                        "price": float(row[3]),
                        "available": bool(row[4])
                    }
                    self.goods.append(good)

        except FileNotFoundError:

            print(f"File {self.file_name} not found. Creating a new file.")

            with open(self.file_name, "w") as file:
                file.write("id,name,description,price,available\n")


    def save_data(self):

        with open(self.file_name, "w") as file:

            file.write("id,name,description,price,available\n")
            for good in self.goods:

                file.write(f"{good['id']},{good['name']},{good['description']},{good['price']},{good['available']}\n")


    def add_good(self, name, description, price):

        new_id = self.goods[-1]["id"] + 1 if self.goods else
        new_good = {
            "id": new_id,
            "name": name,
            "description": description,
            "price": price,
            "available": True
        }

        self.goods.append(new_good)
        self.save_data()


    def remove_good(self, id):

        for i, good in enumerate(self.goods):

            if good["id"] == id:

                del self.goods[i]
                self.save_data()

                print(f"Removed {good['name']} with id {id} from the service.")

                return

        print(f"No good with id {id} found in the service.")


    def update_good(self, id, name=None, description=None, price=None, available=None):

        for good in self.goods:

            if good["id"] == id:

                good["name"] = name or good["name"]
                good["description"] = description or good["description"]
                good["price"] = price or good["price"]
                good["available"] = available or good["available"]

                self.save_data()

                print(f"Updated {good['name']} with id {id} in the service.")

                return

        print(f"No good with id {id} found in the service.")


    def display_goods(self):

        print(f"{'ID':<5}{'Name':<20}{'Description':<30}{'Price':<10}{'Available':<10}")
        print("-" * 75)

        for good in self.goods:

            print(f"{good['id']:<5}{good['name']:<20}{good['description']:<30}{good['price']:<10}{good['available']:<10}")
        print("-" * 75)


    def search_goods(self, query):

        query = query.lower()
        matches = []

        for good in self.goods:

            name = good["name"].lower()
            description = good["description"].lower()

            if query in name or query in description:

                matches.append(good)

        if matches:

            print(f"{'ID':<5}{'Name':<20}{'Description':<30}{'Price':<10}{'Available':<10}")
            print("-" * 75)

            for good in matches:

                print(f"{good['id']:<5}{good['name']:<20}{good['description']:<30}{good['price']:<10}{good['available']:<10}")
            print("-" * 75)

        else:
            print(f"No goods found for the query '{query}'.")


    def display_rent_giver_menu(self):

        print(f"Welcome to {self.name} as a rent-giver!")
        print("Please choose an option:")
        print("1. Add a new good")
        print("2. Remove an existing good")
        print("3. Update an existing good")
        print("4. Display all goods")
        print("5. Exit")


    def handle_rent_giver_input(self):

        self.display_rent_giver_menu()

        while True:

            option = input("Enter your option: ")

            if option == "1":

                name = input("Enter the name of the good: ")
                description = input("Enter the description of the good: ")
                price = float(input("Enter the price per day of the good: "))
                self.add_good(name, description, price)

            elif option == "2":

                id = int(input("Enter the id of the good to remove: "))
                self.remove_good(id)

            elif option == "3":

                id = int(input("Enter the id of the good to update: "))
                name = input("Enter the new name of the good (leave blank to keep the same): ")
                description = input("Enter the new description of the good (leave blank to keep the same): ")
                price = input("Enter the new price per day of the good (leave blank to keep the same): ")
                available = input("Enter the new availability of the good (True or False, leave blank to keep the same): ")
                price = float(price)
                available = available.lower() == "true" if available else None
                self.update_good(id, name, description, price, available)

            elif option == "4":

                self.display_goods()

            elif option == "5":

                break

            else:

                print("Invalid option. Please try again.")


def main():

    rent_service = RentService("Your Rent Service Name", "file_name.csv")


    rent_service.handle_rent_giver_input()



if __name__ == "__main__":
    main()